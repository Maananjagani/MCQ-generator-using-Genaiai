# MCQ-Generator-using-OpenAI

Create .env file in your main directory and add your OpenAI api key
